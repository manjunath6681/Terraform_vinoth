#!/usr/bin/sh

##### Mounting of ebs blocks for separation of data and logs #####
cd /
sudo file -s /dev/xvdb
sudo mkfs -t ext4 /dev/xvdb
sudo mkfs -t ext4 /dev/xvdc
sudo mkdir couchbasedata
sudo mkdir couchbaselogs
sudo mount /dev/xvdb couchbasedata/
sudo mount /dev/xvdc couchbaselogs/
sudo df
sudo cp /etc/fstab /etc/fstab.orig
sudo bash -c echo "/dev/xvdb               /couchbasedata          ext4    defaults,nofail 0 2" >> /etc/fstab
sudo bash -c echo "/dev/xvdc               /couchbaselogs          ext4    defaults,nofail 0 2" >> /etc/fstab
sudo cat /etc/fstab
sudo mount -a


##### Disabling of transparent_hugepages  #####
sudo mv /tmp/couchbase_scripts/disable-thp /etc/init.d/disable-thp
sudo chmod 755 /etc/init.d/disable-thp
sudo sed -i -e 's/\r//g' /etc/init.d/disable-thp
sudo service disable-thp restart
sudo chkconfig disable-thp on
cat /sys/kernel/mm/transparent_hugepage/enabled
cat /sys/kernel/mm/transparent_hugepage/defrag

##### Disable swapiness #####
sudo sysctl vm.swappiness=0
sudo mv /etc/sysctl.conf /etc/sysctl_bkup.conf
sudo mv /tmp/couchbase_scripts/sysctl.conf /etc/sysctl.conf
sudo sed -i -e 's/\r//g' /etc/sysctl.conf


#### Installing and configuring of Couchbase #####
sudo yum install wget -y
wget https://s3.amazonaws.com/couchbasepackage/couchbase-server-enterprise-4.5.1-centos7.x86_64.rpm
rpm --install couchbase-server-enterprise-4.5.1-centos7.x86_64.rpm
chmod 777 /couchbasedata
chmod 777 /couchbaselogs
sudo /etc/init.d/couchbase-server status
sudo /etc/init.d/couchbase-server stop
sudo /etc/init.d/couchbase-server start
sleep 150

#change the logs and data to two different ebs
/opt/couchbase/bin/couchbase-cli node-init -c localhost:8091 -u ec2-user -p ec2user --node-init-data-path=/couchbasedata
/opt/couchbase/bin/couchbase-cli setting-audit -c localhost:8091 -u ec2-user -p ec2user --audit-enabled 1 --audit-log-path=/couchbaselogs
/opt/couchbase/bin/couchbase-cli collect-logs-start -c localhost:8091 -u ec2-user -p ec2user --all-nodes
sudo mv /opt/couchbase/etc/couchbase/static_config /opt/couchbase/etc/couchbase/static_config_bkup
sudo mv /tmp/couchbase_scripts/static_config /opt/couchbase/etc/couchbase/static_config
sudo /etc/init.d/couchbase-server restart
sleep 50


#initialise the cluster
/opt/couchbase/bin/couchbase-cli cluster-init --cluster-username=$1 --cluster-password=$2 --cluster-port=8091 --cluster-ramsize=$3 --cluster-fts-ramsize=$4 --index-storage-setting=memopt

#sleep 20
#Add other nodes in the cluster
#/opt/couchbase/bin/couchbase-cli server-add -c localhost:8091 -u ec2-user -p ec2user --server-add=$1:8091 --server-add-username=ec2-user --server-add-password=ec2user --services=data


#rebalance the cluster for first time
#/opt/couchbase/bin/couchbase-cli rebalance -c localhost:8091 -u ec2-user -p ec2user
