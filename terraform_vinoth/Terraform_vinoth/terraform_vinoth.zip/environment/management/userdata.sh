#!/bin/bash -v
sudo systemctl daemon-reload
sudo systemctl start tomcat
sudo systemctl status tomcat
