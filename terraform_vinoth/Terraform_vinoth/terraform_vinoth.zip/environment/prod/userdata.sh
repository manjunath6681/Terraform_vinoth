#!/bin/bash -v
sudo service start tomcat
