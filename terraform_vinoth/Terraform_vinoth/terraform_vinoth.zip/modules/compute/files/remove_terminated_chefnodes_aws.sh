#!/bin/bash

nodes=$(knife search node "instance_id:*" -a ec2.instance_id)

node_name=""
node_id=""
index=0
for node in $nodes; do
  if [[ $node != "ec2.instance_id:" && $node != i-* ]]; then
    node_name=${node:0:${#node}-1}
  elif [[ $node == i-* ]]; then
    node_id=$node
    echo "Checking $node_name[$node_id]"
    #remove nodes which does not exist in AWS - using default region and acccess key from aws profile file for now..
    if aws ec2 describe-instance-status --instance-ids $node_id>/dev/null; then
       echo "Instance $instanceid exists, nothing to do"
    else
      echo "Instance $instanceid doesn't exist, removing node from Chef server.."
      echo "knife node delete $node_name"
    fi
  fi
done