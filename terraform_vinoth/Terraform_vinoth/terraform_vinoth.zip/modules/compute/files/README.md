## Remove terminated Chef EC2 nodes

The following script remove_terminated_chefnodes_aws.sh can be used to iterate through the current Chef server nodes and remove any of those, which have been terminated and don't exist in AWS.

The script will expect knife to be on the path and be able to authenticate.
The script will pick up the AWS credentials and region from the default location (either environment variables or from aws profile file).

Current limitation therefore is, that the script is checking against one region at the moment.